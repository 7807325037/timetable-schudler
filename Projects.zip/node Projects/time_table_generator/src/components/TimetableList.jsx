import React from 'react';
import { Calendar, Trash2, Clock } from 'lucide-react';

export function TimetableList() {
  const [timetables, setTimetables] = React.useState(
    JSON.parse(localStorage.getItem('timetables') || '[]')
  );

  const deleteTimetable = (id) => {
    if (window.confirm('Are you sure you want to delete this timetable?')) {
      const updatedTimetables = timetables.filter((t) => t.id !== id);
      localStorage.setItem('timetables', JSON.stringify(updatedTimetables));
      setTimetables(updatedTimetables);
    }
  };

  if (timetables.length === 0) {
    return (
      <div className="text-center py-12">
        <Calendar className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">No timetables</h3>
        <p className="mt-1 text-sm text-gray-500">
          Get started by creating a new timetable.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {timetables.map((timetable) => (
        <div
          key={timetable.id}
          className="bg-white rounded-lg shadow-lg overflow-hidden"
        >
          <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
            <div>
              <h3 className="text-lg font-medium text-gray-900">{timetable.name}</h3>
              <p className="text-sm text-gray-500">
                Created by {timetable.createdBy} on{' '}
                {new Date(timetable.createdAt).toLocaleDateString()}
              </p>
            </div>
            <button
              onClick={() => deleteTimetable(timetable.id)}
              className="inline-flex items-center p-2 border border-transparent rounded-full text-red-600 hover:bg-red-50"
            >
              <Trash2 size={20} />
            </button>
          </div>

          <div className="px-6 py-4 overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Time
                  </th>
                  {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map((day) => (
                    <th
                      key={day}
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      {day}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {['8:00 AM', '9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM'].map((time) => (
                  <tr key={time}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex items-center">
                        <Clock size={16} className="mr-2" />
                        {time}
                      </div>
                    </td>
                    {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map((day) => {
                      const slot = timetable.slots.find(
                        (s) => s.day === day && s.time === time
                      );
                      return (
                        <td
                          key={`${day}-${time}`}
                          className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                        >
                          {slot ? (
                            <div className="p-2 bg-blue-50 rounded-md">
                              <div className="font-medium text-blue-900">
                                {slot.subject}
                              </div>
                              <div className="text-sm text-blue-700">
                                {slot.teacher}
                              </div>
                            </div>
                          ) : (
                            <div className="text-center text-gray-400">-</div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </div>
  );
}