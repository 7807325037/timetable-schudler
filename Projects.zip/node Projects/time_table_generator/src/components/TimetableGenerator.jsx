import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Save, Plus } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
const timeSlots = ['8:00 AM', '9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM'];

export function TimetableGenerator() {
  const { user } = useAuthStore();
  const [timetable, setTimetable] = useState([]);
  const [currentSubject, setCurrentSubject] = useState('');
  const [currentTeacher, setCurrentTeacher] = useState('');
  const [timetableName, setTimetableName] = useState('');

  const handleSlotUpdate = (day, time) => {
    if (!currentSubject || !currentTeacher) return;

    const newSlot = {
      day,
      time,
      subject: currentSubject,
      teacher: currentTeacher,
    };

    setTimetable((prev) => {
      const filtered = prev.filter(
        (slot) => !(slot.day === day && slot.time === time)
      );
      return [...filtered, newSlot];
    });
  };

  const getSlotContent = (day, time) => {
    const slot = timetable.find((s) => s.day === day && s.time === time);
    if (!slot) return '';
    return (
      <div className="p-2 bg-blue-50 rounded-md">
        <div className="font-medium text-blue-900">{slot.subject}</div>
        <div className="text-sm text-blue-700">{slot.teacher}</div>
      </div>
    );
  };

  const handleSave = () => {
    if (!timetableName.trim()) {
      alert('Please enter a timetable name');
      return;
    }

    const savedTimetables = JSON.parse(localStorage.getItem('timetables') || '[]');
    const newTimetable = {
      id: Date.now(),
      name: timetableName,
      createdBy: user.name,
      createdAt: new Date().toISOString(),
      slots: timetable,
    };

    savedTimetables.push(newTimetable);
    localStorage.setItem('timetables', JSON.stringify(savedTimetables));
    alert('Timetable saved successfully!');
    
    // Clear form
    setTimetable([]);
    setTimetableName('');
    setCurrentSubject('');
    setCurrentTeacher('');
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
          <Plus className="mr-2" size={24} />
          Create New Timetable
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Timetable Name
            </label>
            <input
              type="text"
              value={timetableName}
              onChange={(e) => setTimetableName(e.target.value)}
              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
              placeholder="Enter timetable name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Subject
            </label>
            <input
              type="text"
              value={currentSubject}
              onChange={(e) => setCurrentSubject(e.target.value)}
              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
              placeholder="Enter subject"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Teacher
            </label>
            <input
              type="text"
              value={currentTeacher}
              onChange={(e) => setCurrentTeacher(e.target.value)}
              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
              placeholder="Enter teacher name"
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg overflow-hidden border border-gray-200">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Time
              </th>
              {days.map((day) => (
                <th
                  key={day}
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {timeSlots.map((time) => (
              <tr key={time}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div className="flex items-center">
                    <Clock size={16} className="mr-2" />
                    {time}
                  </div>
                </td>
                {days.map((day) => (
                  <td
                    key={`${day}-${time}`}
                    className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 cursor-pointer hover:bg-gray-50"
                    onClick={() => handleSlotUpdate(day, time)}
                  >
                    {getSlotContent(day, time) || (
                      <div className="text-center text-gray-400 hover:text-gray-600">
                        Click to add
                      </div>
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 flex justify-end">
        <button
          onClick={handleSave}
          className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <Save className="mr-2" size={20} />
          Save Timetable
        </button>
      </div>
    </div>
  );
}